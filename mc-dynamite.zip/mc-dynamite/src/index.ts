/* eslint-disable @typescript-eslint/no-unused-vars */
import { ComponentSettings, Manager } from '@managed-components/types'

export default async function (manager: Manager, settings: ComponentSettings) {
  manager.addEventListener('pageview', event => {
    const timeElapsed = Date.now()
    const today = new Date(timeElapsed)
    console.debug('today is : ' + today)
  })
}
