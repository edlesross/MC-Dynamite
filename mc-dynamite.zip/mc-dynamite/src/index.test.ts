describe('{{ namespace }}', () => {
  it('example test', () => {
    expect(true).toEqual(true)
  })
})
